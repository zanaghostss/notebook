import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class DataBase {
    ArrayList<Note>notes;
    Scanner scanner=new Scanner(System.in);
    public DataBase() {
        notes=new ArrayList<>();
        login();
    }
    public void searchByName(){
        System.out.println("enter the name of note to search");
        String name=scanner.next();
        for (Note note:notes){
            if(note.getName().equals(name)){
                System.out.println(" found");
                System.out.println(note.toString());
                break;
            }
            else {
                System.out.println("not found");

            }
        }
    }
    public void searchByid(){
        System.out.println("enter the id of note to search");
        int id=scanner.nextInt();
        for (Note note:notes){
            if(note.getId()==id){
                System.out.println("note fount");
                System.out.println(note.toString());
            }
        }
    }
    public void show(){
        for (int i = 0; i <notes.size() ; i++) {
            System.out.println(notes.get(i).toString());
        }
    }
    public void login(){
        while (true){
            System.out.println("1.make a note");
            System.out.println("2.search by name");
            System.out.println("3.search by id");
            int ch=scanner.nextInt();
            switch (ch){
                case 1:
                    notes.add(new Note());
                    break;
                case 2:
                    searchByName();
                    break;
                case 3:
                    searchByid();
                    break;
                default:
                    System.out.println("invaild choice");
                    break;
            }
        }
    }
    public void saveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("notes.txt"))) {
            for (Note note : notes) {
                writer.write(note.getName() + "," + note.getDescriptions() + "," + note.getId());
                writer.newLine();
            }
            System.out.println("Notes have been saved to the file.");
        } catch (IOException e) {
            System.out.println("Error saving notes to the file: " + e.getMessage());
        }
    }

    public void readFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader("notes.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 3) {
                    String name = data[0];
                    String description = data[1];
                    int id = Integer.parseInt(data[2]);
                    notes.add(new Note(name, description, id));
                }
            }
            System.out.println("Notes have been loaded from the file.");
        } catch (IOException e) {
            System.out.println("Error reading notes from the file: " + e.getMessage());
        }
    }


}
