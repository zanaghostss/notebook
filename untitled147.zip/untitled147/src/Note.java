import java.util.Scanner;

public class Note {
    private String name;
    private String descriptions;
    private static int BaseIs=1;
    private int id;

    Scanner scanner=new Scanner(System.in);

    public Note(String name, String descriptions) {
        this.name = name;
        this.descriptions = descriptions;
        this.id=BaseIs++;
    }

    public Note(String name, String description, int id) {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescriptions() {
        return descriptions;
    }

    public void setDescriptions(String descriptions) {
        this.descriptions = descriptions;
    }

    public static int getBaseIs() {
        return BaseIs;
    }

    public static void setBaseIs(int baseIs) {
        BaseIs = baseIs;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void make(){
        System.out.println("enter the name of note");
        this.name=scanner.next();
        System.out.println("enter the description of note");
        this.descriptions=scanner.next();
        this.id=BaseIs++;
    }
    public Note(){make();}

    @Override
    public String toString() {
        return "Note{" +
                "name='" + name + '\'' +
                ", descriptions='" + descriptions + '\'' +
                ", id=" + id +
                '}';
    }
}
